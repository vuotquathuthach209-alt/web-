
import React, { useState, useMemo, useEffect } from 'react';
import { BookingType, FilterState, Hotel, User } from './types';
import { FALLBACK_HOTELS, SHEET_URL, AMENITIES } from './constants';
import Header from './components/Header';
import HeroSearch from './components/HeroSearch';
import HotelGrid from './components/HotelGrid';
import FilterDrawer from './components/FilterDrawer';
import LoginModal from './components/LoginModal';
import PartnerModal from './components/PartnerModal';
import Chatbot from './components/Chatbot';

const App: React.FC = () => {
  const [activeBookingType, setActiveBookingType] = useState<BookingType>(BookingType.HOURLY);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isPartnerModalOpen, setIsPartnerModalOpen] = useState(false);
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Auth state
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  const [filters, setFilters] = useState<FilterState>({
    minRating: 0,
    maxPrice: 1000,
    selectedAmenities: []
  });

  // Load user session from LocalStorage
  useEffect(() => {
    const savedUser = localStorage.getItem('sonder_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
      setIsLoggedIn(true);
    }
  }, []);

  // Helper to convert Google Sheet URL to CSV Export URL
  const getCsvUrl = (url: string) => {
    try {
      const match = url.match(/\/d\/(.+?)\/edit/);
      const id = match ? match[1] : '';
      const gidMatch = url.match(/gid=(\d+)/);
      const gid = gidMatch ? gidMatch[1] : '0';
      return `https://docs.google.com/spreadsheets/d/${id}/export?format=csv&gid=${gid}`;
    } catch (e) {
      return "";
    }
  };

  // CSV Parsing Logic
  const parseCsvData = (csvText: string): Hotel[] => {
    const lines = csvText.split(/\r?\n/);
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
    
    return lines.slice(1).filter(line => line.trim() !== "").map((line, index) => {
      const values = line.split(',').map(v => v.trim());
      const data: any = {};
      headers.forEach((header, i) => {
        data[header] = values[i];
      });

      const ratingNum = parseFloat(data.rating) || 0;
      let ratingText = "Ổn định";
      if (ratingNum >= 9.5) ratingText = "Cực phẩm";
      else if (ratingNum >= 9.0) ratingText = "Xuất sắc";
      else if (ratingNum >= 8.5) ratingText = "Tuyệt vời";
      else if (ratingNum >= 8.0) ratingText = "Rất tốt";

      const formatPrice = (p: string) => p?.toLowerCase().includes('k') ? p : `${p}k`;

      return {
        id: `hotel-${index}`,
        name: data.name || "Khách sạn Sonder",
        address: data.address || "Địa chỉ đang cập nhật",
        rating: ratingNum,
        ratingText: ratingText,
        image: data.image || `https://picsum.photos/id/${100 + index}/800/600`,
        amenities: AMENITIES.slice(0, 3 + (index % 4)),
        pricing: {
          hourly: formatPrice(data.price_hourly || "100"),
          overnight: formatPrice(data.price_overnight || "300"),
          daily: formatPrice(data.price_daily || (parseInt(data.price_overnight || "300") * 1.5).toString())
        }
      };
    });
  };

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      const csvUrl = getCsvUrl(SHEET_URL);
      
      try {
        const response = await fetch(csvUrl);
        if (!response.ok) throw new Error("Network response was not ok");
        const text = await response.text();
        const parsedData = parseCsvData(text);
        setHotels(parsedData);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const filteredHotels = useMemo(() => {
    const targetHotels = hotels.length > 0 ? hotels : (isLoading ? FALLBACK_HOTELS : []);
    
    return targetHotels.filter(hotel => {
      if (isLoading) return true;
      
      if (hotel.rating < filters.minRating) return false;

      const priceStr = hotel.pricing[activeBookingType].replace('k', '');
      const price = parseInt(priceStr);
      if (price > filters.maxPrice) return false;

      if (filters.selectedAmenities.length > 0) {
        const hasAll = filters.selectedAmenities.every(a => hotel.amenities.includes(a));
        if (!hasAll) return false;
      }

      return true;
    });
  }, [activeBookingType, filters, hotels, isLoading]);

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (filters.minRating > 0) count++;
    if (filters.selectedAmenities.length > 0) count += filters.selectedAmenities.length;
    const defaultPrice = activeBookingType === BookingType.HOURLY ? 300 : (activeBookingType === BookingType.OVERNIGHT ? 800 : 1500);
    if (filters.maxPrice < defaultPrice) count++;
    return count;
  }, [filters, activeBookingType]);

  const handleTypeChange = (type: BookingType) => {
    setActiveBookingType(type);
    const defaultPrice = type === BookingType.HOURLY ? 300 : (type === BookingType.OVERNIGHT ? 800 : 1500);
    setFilters(prev => ({ ...prev, maxPrice: defaultPrice }));
  };

  const handleLoginSuccess = (name: string, email: string) => {
    const newUser = {
      name: name,
      email: email,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`
    };
    setIsLoggedIn(true);
    setUser(newUser);
    localStorage.setItem('sonder_user', JSON.stringify(newUser));
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUser(null);
    localStorage.removeItem('sonder_user');
  };

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <Header 
        isLoggedIn={isLoggedIn} 
        user={user} 
        onLoginClick={() => setIsLoginModalOpen(true)}
        onPartnerClick={() => setIsPartnerModalOpen(true)}
        onLogout={handleLogout}
      />
      
      <main>
        <HeroSearch 
          activeType={activeBookingType} 
          onTypeChange={handleTypeChange}
          onOpenFilters={() => setIsFilterOpen(true)}
          activeFilterCount={activeFilterCount}
        />
        
        {isLoading ? (
          <div className="max-w-7xl mx-auto px-4 md:px-8 -mt-8 relative z-20 pb-12 text-center">
            <div className="bg-white rounded-3xl p-12 shadow-sm border border-gray-100 flex flex-col items-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1A3B8B] mb-4"></div>
              <h2 className="text-xl font-bold text-gray-800">Đang tải danh sách phòng...</h2>
              <p className="text-gray-400 mt-2">Sonder đang tìm những căn phòng tuyệt nhất cho bạn</p>
            </div>
          </div>
        ) : (
          <HotelGrid 
            hotels={filteredHotels} 
            activeBookingType={activeBookingType} 
          />
        )}

        <section className="px-4 md:px-8 max-w-7xl mx-auto mb-12">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-gray-800">Khám phá theo chủ đề</h3>
            </div>
            <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-4">
                {[
                    { icon: 'fa-heart', label: 'Tình yêu', color: 'bg-pink-100 text-pink-600' },
                    { icon: 'fa-hotel', label: 'Sang trọng', color: 'bg-yellow-100 text-yellow-600' },
                    { icon: 'fa-leaf', label: 'Thiên nhiên', color: 'bg-green-100 text-green-600' },
                    { icon: 'fa-business-time', label: 'Công tác', color: 'bg-blue-100 text-blue-600' },
                    { icon: 'fa-gem', label: 'Boutique', color: 'bg-purple-100 text-purple-600' },
                ].map((cat, idx) => (
                    <button key={idx} className="flex flex-col items-center gap-2 min-w-[80px]">
                        <div className={`w-14 h-14 ${cat.color} rounded-2xl flex items-center justify-center text-xl shadow-sm transform active:scale-90 transition-transform`}>
                            <i className={`fa-solid ${cat.icon}`}></i>
                        </div>
                        <span className="text-xs font-semibold text-gray-600">{cat.label}</span>
                    </button>
                ))}
            </div>
        </section>
      </main>

      <FilterDrawer 
        isOpen={isFilterOpen}
        onClose={() => setIsFilterOpen(false)}
        filters={filters}
        onFilterChange={setFilters}
        activeBookingType={activeBookingType}
      />

      <LoginModal 
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      <PartnerModal 
        isOpen={isPartnerModalOpen}
        onClose={() => setIsPartnerModalOpen(false)}
      />

      {/* Chatbot Component */}
      <Chatbot />

      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-6 py-2 flex items-center justify-between z-50">
        <button className="flex flex-col items-center gap-1 text-[#1A3B8B]">
          <i className="fa-solid fa-house text-lg"></i>
          <span className="text-[10px] font-bold">Trang chủ</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-gray-400">
          <i className="fa-solid fa-magnifying-glass text-lg"></i>
          <span className="text-[10px] font-bold">Tìm kiếm</span>
        </button>
        <button 
          onClick={() => setIsPartnerModalOpen(true)}
          className="flex flex-col items-center gap-1 text-[#FF5722]"
        >
          <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center -mt-8 border-4 border-white shadow-lg">
             <i className="fa-solid fa-plus text-lg"></i>
          </div>
          <span className="text-[10px] font-bold">Bán phòng</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-gray-400">
          <i className="fa-solid fa-file-invoice text-lg"></i>
          <span className="text-[10px] font-bold">Đơn đặt</span>
        </button>
        <button 
          onClick={isLoggedIn ? undefined : () => setIsLoginModalOpen(true)}
          className="flex flex-col items-center gap-1 text-gray-400"
        >
          {isLoggedIn ? (
            <img src={user?.avatar} className="w-5 h-5 rounded-full" alt="avatar" />
          ) : (
            <i className="fa-solid fa-user text-lg"></i>
          )}
          <span className="text-[10px] font-bold">{isLoggedIn ? 'Tôi' : 'Đăng nhập'}</span>
        </button>
      </nav>

      <footer className="hidden md:block bg-gray-900 text-white py-12 mt-12">
        <div className="max-w-7xl mx-auto px-8 grid grid-cols-4 gap-8">
          <div className="col-span-1">
            <div className="bg-white text-gray-900 font-black px-3 py-1 rounded-lg text-xl tracking-tighter inline-block mb-4">
                SONDER
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Ứng dụng đặt phòng linh hoạt hàng đầu Việt Nam. Mang đến trải nghiệm lưu trú hiện đại, riêng tư và tiện lợi.
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-4">Về SONDER</h4>
            <ul className="text-gray-400 text-sm space-y-2">
              <li className="hover:text-white cursor-pointer transition-colors">Về chúng tôi</li>
              <li className="hover:text-white cursor-pointer transition-colors">Tuyển dụng</li>
              <li className="hover:text-white cursor-pointer transition-colors">Điều khoản & Chính sách</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Hợp tác</h4>
            <ul className="text-gray-400 text-sm space-y-2">
              <li className="hover:text-white cursor-pointer transition-colors">Dành cho khách sạn</li>
              <li className="hover:text-white cursor-pointer transition-colors">Đăng ký đại lý</li>
              <li className="hover:text-white cursor-pointer transition-colors">Affiliate</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Tải ứng dụng</h4>
            <div className="flex flex-col gap-3">
              <img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg" alt="Google Play" className="h-10 w-auto object-contain cursor-pointer" />
              <img src="https://upload.wikimedia.org/wikipedia/commons/3/3c/Download_on_the_App_Store_Badge.svg" alt="App Store" className="h-10 w-auto object-contain cursor-pointer" />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
