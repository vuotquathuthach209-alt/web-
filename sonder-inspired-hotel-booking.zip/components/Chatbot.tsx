
import React, { useState } from 'react';

const Chatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Floating Button */}
      <div 
        className={`fixed z-[150] transition-all duration-500 ease-in-out ${
          isOpen ? 'scale-0 opacity-0 pointer-events-none' : 'scale-100 opacity-100'
        } bottom-24 right-4 md:bottom-8 md:right-8`}
      >
        <button 
          onClick={() => setIsOpen(true)}
          className="relative w-14 h-14 md:w-16 md:h-16 bg-[#FF5722] text-white rounded-full shadow-2xl flex items-center justify-center group hover:bg-[#E64A19] transition-all active:scale-90"
        >
          {/* Pulse Effect Rings */}
          <span className="absolute inset-0 rounded-full bg-[#FF5722] animate-ping opacity-25"></span>
          <span className="absolute inset-[-4px] rounded-full border-2 border-[#FF5722] animate-pulse-soft opacity-20"></span>
          
          <i className="fa-solid fa-comment-dots text-2xl md:text-3xl group-hover:rotate-12 transition-transform"></i>
          
          {/* Tooltip on Hover (Desktop) */}
          <span className="absolute right-20 bg-gray-900 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity hidden md:block uppercase tracking-widest shadow-xl">
            Chat hỗ trợ AI
          </span>
        </button>
      </div>

      {/* Chat Container Window */}
      <div 
        className={`fixed z-[160] transition-all duration-500 transform ${
          isOpen 
            ? 'translate-y-0 opacity-100 scale-100' 
            : 'translate-y-10 opacity-0 scale-95 pointer-events-none'
        } bottom-4 right-4 left-4 md:left-auto md:bottom-8 md:right-8 w-auto md:w-[400px] h-[550px] max-h-[80vh] bg-white rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.2)] overflow-hidden flex flex-col border border-gray-100`}
      >
        {/* Header */}
        <div className="bg-[#FF5722] p-6 text-white flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
              <i className="fa-solid fa-robot text-xl"></i>
            </div>
            <div>
              <h4 className="font-black text-sm tracking-tight leading-none">SONDER AI</h4>
              <p className="text-[10px] text-white/70 font-bold uppercase tracking-widest mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span>
                Đang trực tuyến
              </p>
            </div>
          </div>
          <button 
            onClick={() => setIsOpen(false)}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>

        {/* Chat Body - Đây là nơi Script SDK sẽ render giao diện vào */}
        <div className="flex-1 bg-gray-50 relative overflow-hidden">
          
          {/* Placeholder cho Chatbot SDK */}
          <div id="chatbot-container" className="w-full h-full">
            {/* <!-- CHÈN SCRIPT SDK CHATBOT TẠI ĐÂY --> */}
            
            {/* Nội dung mẫu khi chưa có Script */}
            <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center">
              <div className="w-16 h-16 bg-orange-100 text-[#FF5722] rounded-3xl flex items-center justify-center text-2xl mb-4">
                <i className="fa-solid fa-message-sparkles"></i>
              </div>
              <h5 className="font-bold text-gray-800 mb-2">Chào mừng bạn!</h5>
              <p className="text-xs text-gray-400 leading-relaxed">
                Tôi là trợ lý AI của SONDER. Bạn cần tìm phòng khách sạn hay gặp vấn đề gì không?
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-2">
                <button className="text-[10px] font-bold bg-white border border-gray-100 px-3 py-2 rounded-lg hover:border-[#FF5722] hover:text-[#FF5722] transition-all shadow-sm">
                  Cách đặt phòng?
                </button>
                <button className="text-[10px] font-bold bg-white border border-gray-100 px-3 py-2 rounded-lg hover:border-[#FF5722] hover:text-[#FF5722] transition-all shadow-sm">
                  Chính sách hoàn hủy
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer / Input area - Thường SDK sẽ tự render cái này */}
        <div className="p-4 bg-white border-t border-gray-50">
          <p className="text-[9px] text-center text-gray-300 font-bold uppercase tracking-widest">
            Powered by SONDER AI Ecosystem
          </p>
        </div>
      </div>

      <style>{`
        @keyframes pulse-soft {
          0% { transform: scale(1); opacity: 0.2; }
          50% { transform: scale(1.15); opacity: 0.1; }
          100% { transform: scale(1); opacity: 0.2; }
        }
        .animate-pulse-soft {
          animation: pulse-soft 2s infinite ease-in-out;
        }
      `}</style>
    </>
  );
};

export default Chatbot;
