
import React from 'react';
import { FilterState, BookingType } from '../types';
import { AMENITIES, AMENITY_ICONS } from '../constants';

interface FilterDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  activeBookingType: BookingType;
}

const FilterDrawer: React.FC<FilterDrawerProps> = ({ 
  isOpen, 
  onClose, 
  filters, 
  onFilterChange,
  activeBookingType
}) => {
  if (!isOpen) return null;

  const handleAmenityToggle = (amenity: string) => {
    const next = filters.selectedAmenities.includes(amenity)
      ? filters.selectedAmenities.filter(a => a !== amenity)
      : [...filters.selectedAmenities, amenity];
    onFilterChange({ ...filters, selectedAmenities: next });
  };

  const maxPriceLimit = activeBookingType === BookingType.HOURLY ? 300 : (activeBookingType === BookingType.OVERNIGHT ? 800 : 1500);

  return (
    <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center p-0 md:p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      ></div>

      {/* Content */}
      <div className="relative bg-white w-full md:max-w-md max-h-[90vh] md:rounded-3xl rounded-t-[2.5rem] shadow-2xl overflow-hidden flex flex-col transform transition-transform animate-slide-up">
        {/* Handle for mobile drawer style */}
        <div className="md:hidden w-12 h-1.5 bg-gray-200 rounded-full mx-auto mt-3 mb-1"></div>

        <div className="px-6 py-4 border-b border-gray-50 flex items-center justify-between">
          <h3 className="text-xl font-black text-gray-800 tracking-tight">Bộ lọc tìm kiếm</h3>
          <button onClick={onClose} className="w-10 h-10 bg-gray-50 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors">
            <i className="fa-solid fa-xmark text-gray-500"></i>
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-8 pb-36">
          {/* Price Range */}
          <section>
            <div className="flex justify-between items-end mb-4">
              <label className="font-bold text-gray-800 text-base">Giá tối đa</label>
              <div className="bg-orange-50 px-3 py-1 rounded-lg">
                 <span className="text-[#FF5722] font-black text-lg">{filters.maxPrice}k</span>
                 <span className="text-[#FF5722] text-[10px] font-bold ml-1 uppercase">VND</span>
              </div>
            </div>
            <div className="relative px-2">
                <input 
                type="range" 
                min="50" 
                max={maxPriceLimit} 
                step="10"
                value={filters.maxPrice}
                onChange={(e) => onFilterChange({ ...filters, maxPrice: parseInt(e.target.value) })}
                className="w-full h-1.5 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-[#FF5722]"
                />
                <div className="flex justify-between text-[10px] text-gray-400 mt-3 font-bold uppercase tracking-wider">
                <span>Min 50k</span>
                <span>Max {maxPriceLimit}k</span>
                </div>
            </div>
          </section>

          {/* Rating */}
          <section>
            <label className="font-bold text-gray-800 block mb-4 text-base">Xếp hạng tối thiểu</label>
            <div className="flex gap-2">
              {[0, 8, 9, 9.5].map(val => (
                <button
                  key={val}
                  onClick={() => onFilterChange({ ...filters, minRating: val })}
                  className={`flex-1 py-3 rounded-2xl text-xs font-black transition-all border-2 ${
                    filters.minRating === val 
                    ? 'bg-[#1A3B8B] text-white border-[#1A3B8B] shadow-lg shadow-blue-100' 
                    : 'bg-white text-gray-400 border-gray-100 hover:border-gray-200'
                  }`}
                >
                  {val === 0 ? 'TẤT CẢ' : `${val}+`}
                </button>
              ))}
            </div>
          </section>

          {/* Amenities with Icons */}
          <section>
            <label className="font-bold text-gray-800 block mb-4 text-base">Tiện nghi khách sạn</label>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
              {AMENITIES.map(amenity => {
                const isSelected = filters.selectedAmenities.includes(amenity);
                const iconClass = AMENITY_ICONS[amenity] || 'fa-star';
                
                return (
                  <button
                    key={amenity}
                    onClick={() => handleAmenityToggle(amenity)}
                    className={`flex flex-col items-center justify-center p-4 rounded-2xl border-2 transition-all gap-2 group ${
                      isSelected
                      ? 'bg-blue-50 border-[#1A3B8B] text-[#1A3B8B] shadow-md scale-[1.02]' 
                      : 'bg-white text-gray-400 border-gray-50 hover:border-gray-100'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg transition-all ${
                        isSelected ? 'bg-[#1A3B8B] text-white rotate-[360deg]' : 'bg-gray-50 text-gray-400'
                    }`}>
                        <i className={`fa-solid ${iconClass}`}></i>
                    </div>
                    <span className={`text-[10px] font-black uppercase tracking-tighter ${isSelected ? 'text-[#1A3B8B]' : 'text-gray-400'}`}>
                        {amenity}
                    </span>
                  </button>
                );
              })}
            </div>
          </section>
        </div>

        {/* Footer Actions */}
        <div className="absolute bottom-0 left-0 right-0 p-6 bg-white/80 backdrop-blur-md border-t border-gray-50 flex items-center gap-4">
          <button 
            onClick={() => onFilterChange({ minRating: 0, maxPrice: maxPriceLimit, selectedAmenities: [] })}
            className="px-4 py-4 text-gray-400 font-bold text-xs uppercase tracking-widest hover:text-gray-600 transition-colors"
          >
            Xóa hết
          </button>
          <button 
            onClick={onClose}
            className="flex-1 py-4 bg-[#1A3B8B] text-white rounded-2xl font-black text-sm shadow-xl shadow-blue-200 active:scale-95 transition-all uppercase tracking-widest"
          >
            Áp dụng lọc
          </button>
        </div>
      </div>

      <style>{`
        @keyframes slide-up {
          from { transform: translateY(100%); }
          to { transform: translateY(0); }
        }
        .animate-slide-up {
          animation: slide-up 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }
        input[type='range']::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 20px;
            height: 20px;
            background: #FF5722;
            cursor: pointer;
            border-radius: 50%;
            border: 4px solid white;
            box-shadow: 0 4px 10px rgba(255, 87, 34, 0.3);
        }
      `}</style>
    </div>
  );
};

export default FilterDrawer;
