
import React, { useState } from 'react';
import { User } from '../types';

interface HeaderProps {
  isLoggedIn: boolean;
  user: User | null;
  onLoginClick: () => void;
  onPartnerClick: () => void;
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ isLoggedIn, user, onLoginClick, onPartnerClick, onLogout }) => {
  const [showDropdown, setShowDropdown] = useState(false);

  return (
    <header className="bg-[#1A3B8B] text-white py-3 px-4 md:px-8 flex items-center justify-between sticky top-0 z-50 shadow-md">
      <div className="flex items-center gap-6">
        <div 
          className="bg-white text-[#1A3B8B] font-black px-3 py-1 rounded-lg text-xl tracking-tighter cursor-pointer select-none" 
          onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}
        >
          SONDER
        </div>

        <button 
          onClick={onPartnerClick}
          className="hidden lg:flex items-center gap-2 bg-[#FF5722] hover:bg-[#E64A19] px-4 py-2 rounded-xl transition-all font-bold text-xs shadow-lg shadow-orange-900/20 active:scale-95"
        >
          <i className="fa-solid fa-hotel"></i>
          Đăng ký bán phòng
        </button>
      </div>
      
      <div className="flex items-center gap-3">
        <button className="hidden md:flex items-center gap-2 hover:bg-blue-800 px-3 py-2 rounded-lg transition-colors">
          <i className="fa-solid fa-earth-americas"></i>
          <span className="text-sm font-medium">VN</span>
        </button>

        {!isLoggedIn ? (
          <button 
            onClick={onLoginClick}
            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-4 py-2 rounded-full border border-white/20 transition-all group"
          >
            <i className="fa-solid fa-circle-user text-xl group-hover:scale-110 transition-transform"></i>
            <span className="text-sm font-semibold">Đăng nhập</span>
          </button>
        ) : (
          <div className="relative">
            <button 
              onClick={() => setShowDropdown(!showDropdown)}
              className="flex items-center gap-3 bg-white/10 hover:bg-white/20 pl-1 pr-4 py-1 rounded-full border border-white/20 transition-all"
            >
              <img 
                src={user?.avatar} 
                alt={user?.name} 
                className="w-8 h-8 rounded-full border border-white/20 object-cover"
              />
              <div className="text-left hidden md:block">
                <p className="text-[10px] font-bold text-blue-200 uppercase tracking-widest leading-none">Xin chào,</p>
                <p className="text-xs font-black truncate max-w-[80px]">{user?.name}</p>
              </div>
              <i className={`fa-solid fa-chevron-down text-[10px] transition-transform ${showDropdown ? 'rotate-180' : ''}`}></i>
            </button>

            {showDropdown && (
              <>
                <div className="fixed inset-0 z-0" onClick={() => setShowDropdown(false)}></div>
                <div className="absolute right-0 mt-3 w-56 bg-white rounded-2xl shadow-2xl py-2 z-10 text-gray-800 animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="px-4 py-3 border-b border-gray-50">
                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest">Tài khoản</p>
                    <p className="font-bold text-gray-800 truncate">{user?.email}</p>
                  </div>
                  <div className="py-2">
                    <button className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 flex items-center gap-3 font-semibold">
                      <i className="fa-solid fa-user-gear text-gray-400"></i> Thông tin cá nhân
                    </button>
                    <button className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 flex items-center gap-3 font-semibold">
                      <i className="fa-solid fa-clock-rotate-left text-gray-400"></i> Lịch sử đặt phòng
                    </button>
                    <button className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 flex items-center gap-3 font-semibold">
                      <i className="fa-solid fa-hotel text-orange-500"></i> Quản lý khách sạn
                    </button>
                  </div>
                  <div className="pt-2 border-t border-gray-50">
                    <button 
                      onClick={() => { onLogout(); setShowDropdown(false); }}
                      className="w-full text-left px-4 py-3 text-sm text-red-500 hover:bg-red-50 flex items-center gap-3 font-bold"
                    >
                      <i className="fa-solid fa-right-from-bracket"></i> Đăng xuất
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
