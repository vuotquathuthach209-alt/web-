
import React from 'react';
import { BookingType } from '../types';

interface HeroSearchProps {
  activeType: BookingType;
  onTypeChange: (type: BookingType) => void;
  onOpenFilters: () => void;
  activeFilterCount: number;
}

const HeroSearch: React.FC<HeroSearchProps> = ({ activeType, onTypeChange, onOpenFilters, activeFilterCount }) => {
  return (
    <div className="relative pt-12 pb-20 px-4 md:px-0">
      {/* Background Banner */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80" 
          className="w-full h-full object-cover brightness-[0.4] blur-[2px]"
          alt="Banner"
        />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto">
        <div className="text-center text-white mb-8 px-4">
          <h1 className="text-2xl md:text-4xl font-bold mb-2">Đặt phòng linh hoạt cùng SONDER</h1>
          <p className="text-white/80 text-sm md:text-base">Hơn 5000+ khách sạn chất lượng đang chờ đón bạn</p>
        </div>

        {/* Search Card */}
        <div className="bg-white rounded-2xl shadow-2xl p-4 md:p-6 overflow-hidden">
          {/* Tabs */}
          <div className="flex border-b border-gray-100 mb-6">
            <button 
              onClick={() => onTypeChange(BookingType.HOURLY)}
              className={`flex-1 flex items-center justify-center gap-2 pb-3 font-semibold text-sm transition-all border-b-2 ${
                activeType === BookingType.HOURLY ? 'border-[#1A3B8B] text-[#1A3B8B]' : 'border-transparent text-gray-400'
              }`}
            >
              <i className="fa-solid fa-clock"></i>
              <span>Theo giờ</span>
            </button>
            <button 
              onClick={() => onTypeChange(BookingType.OVERNIGHT)}
              className={`flex-1 flex items-center justify-center gap-2 pb-3 font-semibold text-sm transition-all border-b-2 ${
                activeType === BookingType.OVERNIGHT ? 'border-[#1A3B8B] text-[#1A3B8B]' : 'border-transparent text-gray-400'
              }`}
            >
              <i className="fa-solid fa-moon"></i>
              <span>Qua đêm</span>
            </button>
            <button 
              onClick={() => onTypeChange(BookingType.DAILY)}
              className={`flex-1 flex items-center justify-center gap-2 pb-3 font-semibold text-sm transition-all border-b-2 ${
                activeType === BookingType.DAILY ? 'border-[#1A3B8B] text-[#1A3B8B]' : 'border-transparent text-gray-400'
              }`}
            >
              <i className="fa-solid fa-calendar-days"></i>
              <span>Theo ngày</span>
            </button>
          </div>

          {/* Inputs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="relative">
              <i className="fa-solid fa-location-dot absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
              <input 
                type="text" 
                placeholder="Bạn muốn đi đâu?"
                className="w-full bg-gray-50 border border-gray-100 rounded-xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium text-gray-700"
              />
            </div>

            <div className="relative flex gap-2">
              <div className="relative flex-grow">
                <i className={`absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 ${
                  activeType === BookingType.HOURLY ? 'fa-solid fa-clock' : 'fa-solid fa-calendar'
                }`}></i>
                <input 
                  type="text" 
                  placeholder={activeType === BookingType.HOURLY ? "Hôm nay, 14:00" : "Hôm nay - Mai"}
                  className="w-full bg-gray-50 border border-gray-100 rounded-xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-100 transition-all font-medium text-gray-700"
                />
              </div>
              <button 
                onClick={onOpenFilters}
                className={`flex items-center justify-center w-14 rounded-xl border transition-all ${
                  activeFilterCount > 0 
                  ? 'bg-blue-50 border-[#1A3B8B] text-[#1A3B8B]' 
                  : 'bg-gray-50 border-gray-100 text-gray-400'
                }`}
              >
                <div className="relative">
                  <i className="fa-solid fa-sliders text-xl"></i>
                  {activeFilterCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-[#FF5722] text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-bold">
                      {activeFilterCount}
                    </span>
                  )}
                </div>
              </button>
            </div>
          </div>

          <button className="w-full mt-6 bg-[#FF5722] hover:bg-[#E64A19] text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-orange-200 transition-all transform active:scale-[0.98]">
            TÌM KIẾM NGAY
          </button>
        </div>
      </div>
    </div>
  );
};

export default HeroSearch;
