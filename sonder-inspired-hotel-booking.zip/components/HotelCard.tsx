
import React, { useState } from 'react';
import { Hotel, BookingType } from '../types';

interface HotelCardProps {
  hotel: Hotel;
  activeBookingType: BookingType;
}

const HotelCard: React.FC<HotelCardProps> = ({ hotel, activeBookingType }) => {
  const [isLoaded, setIsLoaded] = useState(false);

  const getDisplayPrice = () => {
    switch (activeBookingType) {
      case BookingType.HOURLY: return hotel.pricing.hourly;
      case BookingType.OVERNIGHT: return hotel.pricing.overnight;
      case BookingType.DAILY: return hotel.pricing.daily;
      default: return hotel.pricing.hourly;
    }
  };

  const getLabel = () => {
    switch (activeBookingType) {
      case BookingType.HOURLY: return '/ giờ';
      case BookingType.OVERNIGHT: return '/ đêm';
      case BookingType.DAILY: return '/ ngày';
      default: return '/ giờ';
    }
  };

  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all group flex flex-col h-full border border-gray-100">
      {/* Image Container with Placeholder */}
      <div className="relative aspect-[4/3] overflow-hidden bg-gray-50">
        {/* Skeleton/Placeholder */}
        {!isLoaded && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100 animate-pulse">
            <i className="fa-solid fa-image text-gray-200 text-3xl"></i>
          </div>
        )}
        
        <img 
          src={hotel.image} 
          alt={hotel.name}
          loading="lazy"
          onLoad={() => setIsLoaded(true)}
          className={`w-full h-full object-cover group-hover:scale-110 transition-all duration-700 ${
            isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
          }`}
        />
        
        <button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center text-gray-400 hover:text-red-500 transition-colors z-10">
          <i className="fa-regular fa-heart"></i>
        </button>
        
        <div className="absolute bottom-2 left-2 bg-[#1A3B8B] text-white px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider z-10">
          Đề xuất
        </div>
      </div>

      <div className="p-3 flex flex-col flex-grow">
        <div className="flex items-center gap-1 mb-1">
          <span className="bg-[#1A3B8B] text-white text-[11px] font-bold px-1.5 py-0.5 rounded">
            {hotel.rating}
          </span>
          <span className="text-[#1A3B8B] text-[11px] font-semibold">{hotel.ratingText}</span>
        </div>
        
        <h3 className="font-bold text-gray-800 text-sm md:text-base mb-1 line-clamp-1 group-hover:text-[#1A3B8B] transition-colors">
          {hotel.name}
        </h3>
        
        <p className="text-gray-400 text-xs flex items-center gap-1 mb-3">
          <i className="fa-solid fa-location-dot"></i>
          {hotel.address}
        </p>

        <div className="mt-auto pt-3 border-t border-gray-50 flex items-end justify-between">
          <div>
            <div className="flex items-baseline gap-0.5">
              <span className="text-[#FF5722] font-black text-lg md:text-xl leading-none">{getDisplayPrice()}</span>
              <span className="text-gray-400 text-[10px] font-medium">{getLabel()}</span>
            </div>
            {activeBookingType === BookingType.HOURLY && (
               <div className="text-[10px] text-gray-400 mt-0.5 flex items-center gap-1">
                 <i className="fa-solid fa-moon text-[8px]"></i>
                 <span>Qua đêm: {hotel.pricing.overnight}</span>
               </div>
            )}
          </div>
          
          <button className="w-8 h-8 rounded-full bg-[#1A3B8B] text-white flex items-center justify-center hover:bg-blue-800 transition-colors">
            <i className="fa-solid fa-chevron-right text-xs"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default HotelCard;
