
import React from 'react';
import { Hotel, BookingType } from '../types';
import HotelCard from './HotelCard';

interface HotelGridProps {
  hotels: Hotel[];
  activeBookingType: BookingType;
}

const HotelGrid: React.FC<HotelGridProps> = ({ hotels, activeBookingType }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 -mt-8 relative z-20 pb-12">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-gray-800 flex items-center gap-2">
            <i className="fa-solid fa-fire text-orange-500"></i>
            {hotels.length > 0 ? 'Khách sạn nổi bật quanh bạn' : 'Không tìm thấy kết quả'}
          </h2>
          <p className="text-sm text-gray-500 mt-1">
            {hotels.length > 0 
              ? `Tìm thấy ${hotels.length} khách sạn phù hợp` 
              : 'Thử thay đổi bộ lọc hoặc tìm kiếm khu vực khác'}
          </p>
        </div>
        {hotels.length > 0 && (
          <button className="hidden md:flex items-center gap-2 text-[#1A3B8B] font-bold text-sm hover:underline">
            Xem tất cả
            <i className="fa-solid fa-arrow-right"></i>
          </button>
        )}
      </div>

      {hotels.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {hotels.map((hotel) => (
            <div key={hotel.id} className="animate-in fade-in slide-in-from-bottom-2 duration-500">
              <HotelCard 
                hotel={hotel} 
                activeBookingType={activeBookingType} 
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-gray-200">
          <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fa-solid fa-magnifying-glass text-3xl text-gray-300"></i>
          </div>
          <h3 className="font-bold text-gray-800 mb-2">Rất tiếc, SONDER chưa tìm thấy phòng phù hợp</h3>
          <p className="text-gray-400 text-sm max-w-xs mx-auto">Hãy thử giảm bớt yêu cầu tiện nghi hoặc nới rộng khoảng giá bạn nhé!</p>
        </div>
      )}
      
      {hotels.length > 0 && (
        <button className="md:hidden w-full mt-6 bg-white border border-gray-200 text-[#1A3B8B] py-3 rounded-xl font-bold text-sm shadow-sm active:scale-95 transition-transform">
          Xem thêm {hotels.length > 4 ? 'kết quả khác' : ''}
        </button>
      )}
    </div>
  );
};

export default HotelGrid;
