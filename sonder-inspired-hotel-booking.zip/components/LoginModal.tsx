
import React, { useState } from 'react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (name: string, email: string) => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose, onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API delay
    setTimeout(() => {
      const displayName = isRegisterMode ? fullName : (email.split('@')[0] || "Thành viên");
      onLoginSuccess(displayName, email);
      setIsSubmitting(false);
      onClose();
      // Reset state
      setEmail('');
      setPassword('');
      setFullName('');
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#1A3B8B]/40 backdrop-blur-md" onClick={onClose}></div>
      
      <div className="relative bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
        <div className="p-8 md:p-10">
          <div className="text-center mb-8">
            <div className="inline-block bg-[#1A3B8B] text-white font-black px-4 py-1.5 rounded-2xl text-2xl tracking-tighter mb-4">
              SONDER
            </div>
            <h2 className="text-2xl font-black text-gray-800">
              {isRegisterMode ? 'Đăng ký tài khoản' : 'Đăng nhập hệ thống'}
            </h2>
            <p className="text-gray-400 text-sm mt-1">Trải nghiệm đặt phòng linh hoạt ngay</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegisterMode && (
              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Họ và tên</label>
                <div className="relative">
                  <i className="fa-solid fa-user absolute left-5 top-1/2 -translate-y-1/2 text-[#1A3B8B]/30"></i>
                  <input 
                    type="text" required value={fullName} onChange={(e) => setFullName(e.target.value)}
                    placeholder="Nguyễn Văn A"
                    className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 pl-14 pr-4 focus:outline-none focus:ring-4 focus:ring-blue-50 transition-all font-semibold"
                  />
                </div>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Email</label>
              <div className="relative">
                <i className="fa-solid fa-envelope absolute left-5 top-1/2 -translate-y-1/2 text-[#1A3B8B]/30"></i>
                <input 
                  type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                  placeholder="vidu@email.com"
                  className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 pl-14 pr-4 focus:outline-none focus:ring-4 focus:ring-blue-50 transition-all font-semibold"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Mật khẩu</label>
              <div className="relative">
                <i className="fa-solid fa-lock absolute left-5 top-1/2 -translate-y-1/2 text-[#1A3B8B]/30"></i>
                <input 
                  type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 pl-14 pr-4 focus:outline-none focus:ring-4 focus:ring-blue-50 transition-all font-semibold"
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#1A3B8B] text-white py-4 rounded-2xl font-black text-sm shadow-xl shadow-blue-200 active:scale-95 transition-all uppercase tracking-widest flex items-center justify-center gap-3"
            >
              {isSubmitting ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <span>{isRegisterMode ? 'Tạo tài khoản' : 'Đăng nhập ngay'}</span>
              )}
            </button>
          </form>

          <div className="mt-8 text-center">
            <button 
              onClick={() => setIsRegisterMode(!isRegisterMode)}
              className="text-xs font-bold text-gray-500 hover:text-[#1A3B8B] transition-colors"
            >
              {isRegisterMode ? 'Đã có tài khoản? Đăng nhập' : 'Chưa có tài khoản? Đăng ký ngay'}
            </button>
          </div>
        </div>
        
        <button onClick={onClose} className="absolute top-6 right-6 text-gray-300 hover:text-gray-500">
          <i className="fa-solid fa-xmark text-xl"></i>
        </button>
      </div>
    </div>
  );
};

export default LoginModal;
