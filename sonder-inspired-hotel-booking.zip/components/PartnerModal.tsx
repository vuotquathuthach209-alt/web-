
import React, { useState, useRef } from 'react';
import { EMAILJS_CONFIG } from '../constants';

// Declare emailjs for TypeScript (via CDN)
declare const emailjs: any;

interface PartnerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PartnerModal: React.FC<PartnerModalProps> = ({ isOpen, onClose }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const [recordCode, setRecordCode] = useState('');
  
  const [formData, setFormData] = useState({
    hotelName: '',
    address: '',
    price: '',
    contactName: '',
    email: ''
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const sendEmail = async (code: string) => {
    // Cấu trúc nội dung Email gửi đi (Template) chuẩn doanh nghiệp
    const templateParams = {
      to_name: formData.contactName,
      to_email: formData.email,
      hotel_name: formData.hotelName,
      record_code: code,
      subject: "Xác nhận hồ sơ đăng ký Đối tác SONDER",
      content: `Kính chào ${formData.contactName},
      Hệ thống đã nhận được yêu cầu đăng ký khách sạn ${formData.hotelName}.
      Chúng tôi sẽ thẩm định và phản hồi trong 24h.
      Mã hồ sơ: ${code}.`
    };

    if (typeof emailjs !== 'undefined' && EMAILJS_CONFIG.PUBLIC_KEY !== 'YOUR_PUBLIC_KEY') {
      try {
        emailjs.init(EMAILJS_CONFIG.PUBLIC_KEY);
        await emailjs.send(EMAILJS_CONFIG.SERVICE_ID, EMAILJS_CONFIG.TEMPLATE_ID, templateParams);
        console.log("Email sent successfully via EmailJS");
      } catch (err) {
        console.error("EmailJS Error:", err);
      }
    } else {
      console.warn("EmailJS chưa được cấu hình. Xem nội dung email tại console.");
      console.log("MOCK EMAIL SENT:", templateParams);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const code = 'SD-' + Math.floor(Math.random() * 900000 + 100000);
    setRecordCode(code);

    // Xử lý gửi mail
    await sendEmail(code);

    // Simulate delay
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#0A1931]/80 backdrop-blur-md" onClick={isSubmitting ? undefined : onClose}></div>

      <div className="relative bg-white w-full max-w-2xl rounded-[2rem] shadow-2xl overflow-hidden flex flex-col animate-in zoom-in duration-300">
        <div className="px-8 py-6 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
          <div>
            <h3 className="text-xl font-black text-[#1A3B8B]">Hợp tác cùng SONDER</h3>
            <p className="text-xs text-gray-400 font-medium">Đăng ký bán phòng khách sạn của bạn</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <i className="fa-solid fa-xmark text-xl"></i>
          </button>
        </div>

        <div className="p-8 overflow-y-auto max-h-[80vh]">
          {isSuccess ? (
            <div className="text-center py-10 animate-in fade-in slide-in-from-bottom-4">
              <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-3xl mx-auto mb-6">
                <i className="fa-solid fa-check"></i>
              </div>
              <h4 className="text-2xl font-black text-gray-800 mb-2">Đăng ký thành công!</h4>
              <p className="text-gray-500 mb-6">
                Hồ sơ <span className="font-bold">{recordCode}</span> đã được gửi đi. Vui lòng kiểm tra email xác nhận.
              </p>
              <button onClick={onClose} className="bg-[#1A3B8B] text-white px-8 py-3 rounded-xl font-bold">Quay lại</button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-gray-500 mb-1 block">Tên khách sạn</label>
                    <input required name="hotelName" value={formData.hotelName} onChange={handleInputChange} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-blue-100 outline-none" placeholder="Sonder Premium..." />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-500 mb-1 block">Giá dự kiến (VND)</label>
                    <input required name="price" value={formData.price} onChange={handleInputChange} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-blue-100 outline-none" placeholder="500.000" />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-500 mb-1 block">Địa chỉ</label>
                    <textarea required name="address" value={formData.address} onChange={handleInputChange} rows={3} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-blue-100 outline-none resize-none" placeholder="Địa chỉ chi tiết..." />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-gray-500 mb-1 block">Tên người liên hệ</label>
                    <input required name="contactName" value={formData.contactName} onChange={handleInputChange} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-blue-100 outline-none" placeholder="Nguyễn Văn A" />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-500 mb-1 block">Email nhận thông báo</label>
                    <input required type="email" name="email" value={formData.email} onChange={handleInputChange} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-blue-100 outline-none" placeholder="vidu@email.com" />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-500 mb-1 block">Hình ảnh thực tế</label>
                    <div 
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full aspect-video rounded-2xl border-2 border-dashed border-gray-200 bg-gray-50 flex flex-col items-center justify-center cursor-pointer overflow-hidden relative group"
                    >
                      {previewImage ? (
                        <img src={previewImage} className="w-full h-full object-cover" />
                      ) : (
                        <>
                          <i className="fa-solid fa-camera text-2xl text-gray-300"></i>
                          <span className="text-[10px] font-bold text-gray-400 mt-2 uppercase">Chọn ảnh</span>
                        </>
                      )}
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-xs font-bold">Thay đổi ảnh</div>
                    </div>
                    <input type="file" ref={fileInputRef} onChange={handleImageChange} accept="image/*" className="hidden" />
                  </div>
                </div>
              </div>

              <button 
                type="submit" disabled={isSubmitting}
                className="w-full bg-[#FF5722] text-white py-4 rounded-2xl font-black text-sm tracking-widest uppercase shadow-xl shadow-orange-900/10 flex items-center justify-center gap-3 transition-all hover:bg-orange-600"
              >
                {isSubmitting ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <><span>Gửi đăng ký ngay</span><i className="fa-solid fa-paper-plane"></i></>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default PartnerModal;
