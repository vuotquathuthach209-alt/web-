
import { Hotel } from './types';

export const SHEET_URL = "https://docs.google.com/spreadsheets/d/1sjk01x1Jsnjm_VUMNWlV7QVqTKYlT1_Y1hqnWpjk2c4/edit?gid=0#gid=0";

export const AMENITIES = [
  'Wifi', 'Bồn tắm', 'Smart TV', 'Thang máy', 'Giữ xe', 'Máy sấy', 'Tủ lạnh'
];

export const AMENITY_ICONS: Record<string, string> = {
  'Wifi': 'fa-wifi',
  'Bồn tắm': 'fa-bath',
  'Smart TV': 'fa-tv',
  'Thang máy': 'fa-elevator',
  'Giữ xe': 'fa-square-parking',
  'Máy sấy': 'fa-wind',
  'Tủ lạnh': 'fa-snowflake'
};

// ==========================================
// EMAILJS CONFIGURATION
// Đăng ký tại: https://www.emailjs.com/
// ==========================================
export const EMAILJS_CONFIG = {
  PUBLIC_KEY: "YOUR_PUBLIC_KEY",     // Thay bằng Public Key từ Account Tab
  SERVICE_ID: "YOUR_SERVICE_ID",     // Thay bằng Service ID từ Email Services
  TEMPLATE_ID: "YOUR_TEMPLATE_ID"    // Thay bằng Template ID từ Email Templates
};

export const FALLBACK_HOTELS: Hotel[] = [
  {
    id: 'f1',
    name: 'Đang tải dữ liệu...',
    address: 'Vui lòng chờ trong giây lát',
    rating: 0,
    ratingText: '...',
    image: 'https://placehold.co/600x400?text=Loading...',
    amenities: [],
    pricing: { hourly: '0k', overnight: '0k', daily: '0k' }
  }
];
