
export enum BookingType {
  HOURLY = 'hourly',
  OVERNIGHT = 'overnight',
  DAILY = 'daily'
}

export interface Pricing {
  hourly: string;
  overnight: string;
  daily: string;
}

export interface Hotel {
  id: string;
  name: string;
  address: string;
  rating: number;
  ratingText: string;
  image: string;
  pricing: Pricing;
  amenities: string[];
  isFavorite?: boolean;
}

export interface FilterState {
  minRating: number;
  maxPrice: number;
  selectedAmenities: string[];
}

export interface User {
  name: string;
  email: string;
  avatar: string;
}
